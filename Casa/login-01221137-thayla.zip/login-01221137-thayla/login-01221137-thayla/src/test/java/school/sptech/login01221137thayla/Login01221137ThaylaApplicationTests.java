package school.sptech.login01221137thayla;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Login01221137ThaylaApplicationTests {

	@Test
	void contextLoads() {
	}

}
