package school.sptech.login01221137thayla;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Login01221137ThaylaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Login01221137ThaylaApplication.class, args);
	}

}
