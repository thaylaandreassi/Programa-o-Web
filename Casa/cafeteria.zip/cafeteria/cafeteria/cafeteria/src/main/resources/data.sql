INSERT INTO cliente
    (nome)
VALUES
    ('Joaozinho'),
    ('Pedrinho'),
    ('Aninha');

INSERT INTO pedido
    (nome, custo, cliente_id)
VALUES
    ('Brownie', 8.0, 1),
    ('Ice Tea', 12.0, 2),
    ('Hot Chocolate', 9.50, 3);