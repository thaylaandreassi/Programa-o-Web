package school.sptech.atividadevalendonota2sprint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtividadeValendoNota2sprintApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtividadeValendoNota2sprintApplication.class, args);
	}

}
