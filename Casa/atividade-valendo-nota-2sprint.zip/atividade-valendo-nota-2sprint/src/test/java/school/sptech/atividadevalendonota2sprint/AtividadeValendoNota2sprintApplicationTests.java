package school.sptech.atividadevalendonota2sprint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtividadeValendoNota2sprintApplicationTests {

	@Test
	void contextLoads() {
	}

}
