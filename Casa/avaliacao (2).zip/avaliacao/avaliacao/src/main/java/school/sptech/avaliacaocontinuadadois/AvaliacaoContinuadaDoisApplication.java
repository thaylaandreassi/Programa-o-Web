package school.sptech.avaliacaocontinuadadois;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvaliacaoContinuadaDoisApplication {

	public static void main(String[] args) {
		SpringApplication.run(AvaliacaoContinuadaDoisApplication.class, args);
	}

}
