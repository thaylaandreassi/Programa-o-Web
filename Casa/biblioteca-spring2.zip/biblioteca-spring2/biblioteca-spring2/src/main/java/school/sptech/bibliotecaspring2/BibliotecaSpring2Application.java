package school.sptech.bibliotecaspring2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BibliotecaSpring2Application {

	public static void main(String[] args) {
		SpringApplication.run(BibliotecaSpring2Application.class, args);
	}

}
