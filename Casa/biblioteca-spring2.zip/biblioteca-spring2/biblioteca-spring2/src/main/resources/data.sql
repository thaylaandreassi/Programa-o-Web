INSERT INTO escritor
(nome)
VALUES
('William Shakespeare'),
('Betty Jane'),
('Manuel Antonio de Almeida'),
('Eca de Queiroz'),
('Machado de Assis');
INSERT INTO livro
(nome, escritor_id, anoLancamento, editora)
VALUES
('Romeu e Julieta', 1, '1597-06-11', 'Novo seculo'),
('Mulheres Cheias de Graça', 2, '2008-07-18', 'Martim Clarite'),
('Memórias de um Sargento de Milícias', 3, '1994-10-14', 'Vida'),
('A cidade e as serras', 4, '1960-09-08', 'Novo seculo'),
('Dom Casmurro', 5, '2006-10-06', 'Editora Avenida')