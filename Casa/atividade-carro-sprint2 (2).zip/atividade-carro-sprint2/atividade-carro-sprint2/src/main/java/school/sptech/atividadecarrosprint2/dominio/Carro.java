package school.sptech.atividadecarrosprint2.dominio;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.*;
import java.time.LocalDate;

@Entity
public class Carro {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Integer id;

    @NotBlank
    @Size(min = 2, max = 12)
    private String nome;

    @NotBlank
    @Size(min = 2, max = 12)
    private String fabricante;

    @PastOrPresent
    private LocalDate dataFabricacao;

    @NotBlank
    @Size(min = 1950, max = 2022)
    private Integer modelo;

    @NotBlank
    @DecimalMin("0.2")
    @DecimalMax("7.0")
    private Double potenciaMotor;

}
