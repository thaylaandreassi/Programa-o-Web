package school.sptech.exercicioprodutoentrega;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExercicioProdutoEntregaApplicationTests {

	@Test
	void contextLoads() {
	}

}
