package school.sptech.projeto05validations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projeto05ValidationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
