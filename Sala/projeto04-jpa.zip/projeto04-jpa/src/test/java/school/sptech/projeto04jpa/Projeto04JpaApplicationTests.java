package school.sptech.projeto04jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projeto04JpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
